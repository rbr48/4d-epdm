# Empirical Implementation Chapter — 4D-EPDM

## Status
This chapter converts the conceptual model into a reproducible empirical design. It does **not** fabricate coefficient estimates. Numerical findings become dissertation findings only after the real-data pipeline is run against a frozen data vintage and passes the validation protocol.

## 1. Data architecture
The empirical panel combines WDI indicators with Penn World Table 11.0 productivity/capital/human-capital variables. WDI currently contains more than 1,400 time-series indicators across 217 economies, and its official bulk/API interfaces are designed for reproducible retrieval. PWT 11.0 covers 185 countries from 1950–2023 and supplies output, inputs and productivity variables.

The preferred analysis window is 1990–2023/24 for the cross-country panel because indicator coverage becomes substantially more consistent. Japan’s historical narrative is separately reconstructed over the long-run postwar period using historical sources.

## 2. Latent dimensions
The four dimensions are not observed variables. They are latent constructs approximated from multiple indicators:

- K: capital/infrastructure
- H: human capital
- T: technology/productivity
- I: institutional/global integration

Within each dimension, variables are winsorized, median-imputed only when justified, standardized, and reduced using the first principal component. The sign is oriented so that higher values correspond to stronger capability. Alternative specifications use equal-weight standardized means; both must be compared.

## 3. Outcome equation
The baseline growth equation is:

`g_it = alpha_i + tau_t + beta'X_it + X_it'Gamma X_it + rho g_i,t-1 + epsilon_it`

where X=(K,H,T,I). The interaction matrix Gamma captures complementarity. Country effects control for time-invariant heterogeneity and year effects capture common global shocks.

## 4. Bayesian estimation
The first implementation uses a conjugate Normal-Inverse-Gamma posterior for the linear conditional model. This provides exact conditional posterior draws for coefficients and variance under the stated prior. The dissertation should subsequently compare this with a full Bayesian hierarchical/state-space model using Hamiltonian Monte Carlo where computationally feasible.

Posterior uncertainty must be propagated into every forecast. Point estimates alone are insufficient.

## 5. State transition
For long-horizon policy simulations:

`X_(t+1) = clip(X_t + A(1-X_t) + B P_t + u_t, 0, 1)`

where P is a policy-intensity vector and u is a stochastic innovation. A full thesis implementation should estimate A and B from observed changes rather than choose them by hand. The current software therefore labels the policy transition parameters as scenario assumptions until estimated.

## 6. EPI construction
The baseline index is:

`EPI_t = 100 * K^wK * H^wH * T^wT * I^wI`

with equal weights as the default. The geometric mean is deliberately used because it penalizes severe weakness in a dimension. Interaction-adjusted EPI is reported separately and should not be conflated with the base index.

## 7. Economic-superpower threshold
Because “economic superpower” has no official statistical definition, the threshold must be pre-registered. The software defaults to EPI >= 80, but this is a research convention, not an observed fact. Robustness must be tested at alternative thresholds such as 70, 75, 80, 85 and 90.

## 8. Japan identification strategy
Japan is treated as a historical benchmark rather than a simple one-country regression. The analysis reconstructs the sequence:

capital destruction/reconstruction → investment → labour reallocation → technology adoption → productivity → exports → industrial complexity.

The Bank of Japan notes that Japan lost capital stock equivalent to roughly 86% of GDP during WWII and then experienced average growth close to 10% during the high-growth period. Research by Ikeda and Morita estimates that barriers to technology adoption explain about 40% of the postwar miracle in their model. These findings motivate the technology-absorption component of 4D-EPDM.

## 9. Bangladesh identification strategy
Bangladesh is evaluated against both its own historical trajectory and a donor-pool counterfactual consisting of Asian economies with comparable initial development conditions. A synthetic-control specification should be estimated for major structural reforms and export transformation episodes.

The model should explicitly test whether the country’s constraint shifted from basic capital/labour accumulation toward productivity, institutions, financial intermediation and diversification.

## 10. Forecast validation
The final dissertation must use rolling-origin evaluation. For each forecast origin t:

1. estimate using data available only through t;
2. forecast t+h;
3. compare with subsequently observed outcomes;
4. repeat across all feasible origins.

Report RMSE, MAE, log predictive density, interval coverage, CRPS where available, Brier score for threshold events, and calibration curves.

A model is not accepted merely because it fits historical data.

## 11. Benchmark models
4D-EPDM should be compared against:

- random-walk/constant-growth benchmark;
- AR(1) growth model;
- standard Solow-style growth regression;
- fixed-effects panel without interactions;
- fixed-effects panel with interactions;
- Bayesian 4D model;
- full dynamic state-space version.

The proposed model should earn its complexity by producing superior predictive performance or more useful policy counterfactuals.

## 12. Causal interpretation
The model is primarily a dynamic explanatory and forecasting framework. Association is not automatically causation. Causal claims require additional identification, including instruments, natural experiments, policy timing, synthetic controls or difference-in-differences where credible.

## 13. Policy counterfactuals
Bangladesh scenarios should be pre-registered as:

A. status quo;
B. macro-financial stabilization;
C. export diversification;
D. technology acceleration;
E. human-capital acceleration;
F. institutional acceleration;
G. integrated 4D transformation.

Each scenario changes only specified policy levers. Monte Carlo simulation propagates parameter uncertainty, state uncertainty and shock uncertainty.

## 14. Decision criterion
For policy i:

`M_i = d E[EPI_T] / d P_i`

and

`R_i = d Pr(EPI_T >= threshold) / d P_i`.

A robust recommendation should remain positive across reasonable priors, weights, thresholds and data definitions.

## 15. Reproducibility requirements
The final dissertation archive must contain:

- frozen raw data;
- data dictionaries;
- source URLs/DOIs;
- retrieval dates;
- SHA-256 hashes;
- cleaning scripts;
- analysis scripts;
- configuration file;
- exact software versions;
- random seeds;
- model output;
- validation output;
- preregistered threshold definitions;
- a complete change log.

## 16. Current evidence boundary
The current software has been executed successfully in demo mode using simulated data. This proves the computational pipeline runs, but it is not evidence about Japan or Bangladesh. Real-data execution is required before reporting estimated coefficients, EPI scores, probabilities or policy rankings as empirical findings.
