# 4D-EPDM: Reproducible Japan–Bangladesh Economic Power Research Package

## Purpose
This package upgrades the conceptual thesis into a reproducible empirical research pipeline.

It implements:
1. WDI/PWT data ingestion;
2. four-dimensional indicator construction (K, H, T, I);
3. cross-country panel preparation;
4. PCA-based latent-index estimation;
5. Bayesian growth regression with pairwise 4D interactions;
6. Monte Carlo policy/scenario forecasting;
7. Economic Power Index (EPI) calculation;
8. threshold probability estimation;
9. sensitivity analysis;
10. automated tables and figures.

**Important:** the package distinguishes *demo results* from *empirical results*. The included demo dataset is simulated solely to test the pipeline. It must never be presented as observed economic data.

## Scientific standard
No empirical economic model can honestly provide literal 100% certainty. This implementation therefore reports posterior distributions, credible intervals, forecast errors and threshold probabilities.

## Data sources
The real-data pipeline is designed around:
- World Bank World Development Indicators (WDI);
- Penn World Table 11.0;
- World Governance Indicators (through WDI where available).

WDI bulk/API documentation: https://datatopics.worldbank.org/world-development-indicators/
PWT 11.0: https://www.rug.nl/ggdc/productivity/pwt/

## Countries
Core treatment and comparator set:
Japan, Bangladesh, South Korea, Taiwan, Singapore, China, Malaysia, Thailand, Vietnam, India, Indonesia, Philippines, selected OECD comparators.

## Main model
Let X=(K,H,T,I). The normalized latent dimensions enter:

g_it = a_i + tau_t + beta'X_it + X_it' Gamma X_it + epsilon_it

and

EPI_it = 100 * product_j X_ijt^(w_j) * (1 + sum_{j<k} gamma_jk X_ijt X_ikt)

Forecasts propagate the state variables through a policy-controlled transition function and simulate parameter and shock uncertainty.

## Running
### 1. Install
pip install -r requirements.txt

### 2. Run demo
python run_pipeline.py --demo

### 3. Run real data
python run_pipeline.py --download

This requires internet access on the machine executing the script. The script downloads WDI through the official API and expects a PWT 11.0 file in `data/pwt110.xlsx` or a configured URL.

### 4. Outputs
Results are written to `outputs/`:
- panel_4d.csv
- dimension_loadings.csv
- posterior_coefficients.csv
- forecast_distribution.csv
- policy_sensitivity.csv
- figures/*.png
- model_report.md

## Dissertation use
The demo mode validates software correctness only. The real-data mode must be run with a frozen data vintage, documented download date, checksums, preprocessing log, and out-of-sample evaluation before numerical findings are included in a dissertation.
