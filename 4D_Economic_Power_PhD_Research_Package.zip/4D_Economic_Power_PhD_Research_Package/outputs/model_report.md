# Automated Model Report

Mode: DEMO / SYNTHETIC

## Model
Bayesian linear growth model with four latent dimensions (K,H,T,I), six pairwise interaction terms, lagged growth, and country fixed effects.

## Important status
This report is **not** a completed causal estimate unless real WDI/PWT data are used and all validation diagnostics pass.

## Output files
- `panel_4d.csv`
- `posterior_coefficients.csv`
- `latest_epi.csv`
- `forecast_distribution.csv`
- `forecast_probabilities.csv`
- `policy_sensitivity.csv`
- `figures/epi_JPN.png`
- `figures/epi_BGD.png`
- `figures/bangladesh_scenarios.png`

## Interpretation
The EPI is a research index, not an official measure of national power. Threshold 80 is a declared analytical convention and must be sensitivity-tested.

## Validation still required
- rolling-origin out-of-sample forecasts;
- posterior predictive checks;
- calibration curves;
- alternative indicator sets;
- alternative normalization;
- alternative weights;
- structural-break tests;
- placebo countries;
- sensitivity to missing-data treatment;
- comparison with non-Bayesian benchmarks.
