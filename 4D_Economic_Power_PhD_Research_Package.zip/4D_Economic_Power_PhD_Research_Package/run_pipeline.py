#!/usr/bin/env python3
"""
4D-EPDM reproducible research pipeline.

Modes:
  --demo       Run entirely on simulated data to validate the pipeline.
  --download   Download WDI indicators, then combine with local PWT 11.0 if available.

This is a research implementation, not a claim of causal identification.
"""

import argparse, json, math, os, sys, zipfile, io
from pathlib import Path
import numpy as np
import pandas as pd
import requests
import matplotlib.pyplot as plt
from scipy import linalg, stats
import statsmodels.api as sm

ROOT=Path(__file__).resolve().parent
OUT=ROOT/"outputs"; FIG=OUT/"figures"; DATA=ROOT/"data"
OUT.mkdir(exist_ok=True); FIG.mkdir(exist_ok=True); DATA.mkdir(exist_ok=True)

COUNTRIES=["JPN","BGD","KOR","TWN","SGP","CHN","MYS","THA","VNM","IND","IDN","PHL"]
IND={
"GDP_GROWTH":"NY.GDP.MKTP.KD.ZG",
"GDP_PC":"NY.GDP.PCAP.PP.KD",
"CAPITAL_FORMATION":"NE.GDI.TOTL.ZS",
"FDI":"BX.KLT.DINV.WD.GD.ZS",
"ELECTRICITY":"EG.ELC.ACCS.ZS",
"LIFE_EXPECTANCY":"SP.DYN.LE00.IN",
"SCHOOLING":"SE.SEC.ENRR",
"RND":"GB.XPD.RSDV.GD.ZS",
"HIGH_TECH_EXPORTS":"TX.VAL.TECH.MF.ZS",
"TAX_REVENUE":"GC.TAX.TOTL.GD.ZS",
"GOVERNMENT_EFFECTIVENESS":"GE.EST",
"TRADE":"NE.TRD.GNFS.ZS"
}

def fetch_wdi(countries=COUNTRIES,start=1990,end=2024):
    frames=[]
    for name,code in IND.items():
        for iso in countries:
            url=f"https://api.worldbank.org/v2/country/{iso}/indicator/{code}"
            params={"format":"json","per_page":1000,"date":f"{start}:{end}"}
            r=requests.get(url,params=params,timeout=60)
            r.raise_for_status()
            js=r.json()
            rows=js[1] if len(js)>1 and js[1] else []
            frames += [{"iso":iso,"year":int(x["date"]),"indicator":name,
                        "value":x["value"]} for x in rows]
    return pd.DataFrame(frames)

def wide_wdi(long):
    return long.pivot_table(index=["iso","year"],columns="indicator",
                            values="value",aggfunc="first").reset_index()

def load_pwt(path=DATA/"pwt110.xlsx"):
    if not path.exists():
        return None
    x=pd.read_excel(path,sheet_name="Data")
    cols={c.lower():c for c in x.columns}
    # PWT variable names are usually lowercase.
    rename={}
    for wanted in ["countrycode","year","ctfp","hc","rkna","emp","pop","cgdpo","rgdpo"]:
        if wanted in cols: rename[cols[wanted]]=wanted
    x=x.rename(columns=rename)
    keep=[c for c in ["countrycode","year","ctfp","hc","rkna","emp","pop","cgdpo","rgdpo"] if c in x.columns]
    x=x[keep].rename(columns={"countrycode":"iso"})
    return x

def demo_data(seed=42,start=1990,end=2024):
    rng=np.random.default_rng(seed)
    rows=[]
    # Synthetic but structurally plausible latent trajectories.
    base={"JPN":[.82,.84,.86,.88],"BGD":[.28,.34,.30,.31],"KOR":[.70,.68,.76,.72],
          "SGP":[.78,.83,.91,.90],"CHN":[.38,.43,.55,.48],"IND":[.25,.35,.40,.34],
          "VNM":[.24,.35,.42,.38],"MYS":[.48,.55,.58,.55],"THA":[.45,.53,.55,.50],
          "IDN":[.30,.40,.43,.38],"PHL":[.30,.42,.40,.37],"TWN":[.70,.75,.85,.80]}
    trends={"JPN":[.003,.002,.001,.001],"BGD":[.010,.008,.012,.008],"KOR":[.006,.006,.007,.005],
            "SGP":[.005,.004,.006,.004],"CHN":[.010,.012,.010,.008],"IND":[.009,.010,.010,.007],
            "VNM":[.012,.010,.010,.008],"MYS":[.008,.007,.006,.005],"THA":[.006,.006,.004,.004],
            "IDN":[.008,.008,.007,.006],"PHL":[.009,.008,.007,.006],"TWN":[.005,.005,.006,.004]}
    for iso in COUNTRIES:
        for year in range(start,end+1):
            t=year-start
            z=np.array(base[iso])+t*np.array(trends[iso])+rng.normal(0,.025,4)
            z=np.clip(z,.02,.98)
            # growth depends on dimensions + interactions
            g=2.0+4.2*z.mean()+1.8*(z[0]*z[2]+z[1]*z[3])+rng.normal(0,1.0)
            rows.append([iso,year,*z,g])
    return pd.DataFrame(rows,columns=["iso","year","K","H","T","I","GDP_GROWTH"])

def robust_normalize(s):
    q1,q99=s.quantile(.01),s.quantile(.99)
    x=s.clip(q1,q99)
    return (x-q1)/(q99-q1+1e-12)

def build_dimensions(wide,pwt=None):
    d=wide.copy()
    if pwt is not None:
        d=d.merge(pwt,on=["iso","year"],how="left",suffixes=("","_pwt"))
        if "ctfp" in d: d["PWT_TFP"]=d["ctfp"]
        if "hc" in d: d["PWT_HC"]=d["hc"]
        if "rkna" in d: d["PWT_CAPITAL"]=d["rkna"]
    # Indicator groups. PCA is applied within each group after standardization.
    groups={
      "K":["CAPITAL_FORMATION","FDI","ELECTRICITY"],
      "H":["LIFE_EXPECTANCY","SCHOOLING","PWT_HC"],
      "T":["RND","HIGH_TECH_EXPORTS","PWT_TFP"],
      "I":["TAX_REVENUE","GOVERNMENT_EFFECTIVENESS","TRADE"]
    }
    for dim,cols in groups.items():
        avail=[c for c in cols if c in d.columns and d[c].notna().sum()>10]
        if not avail: raise ValueError(f"No indicators available for dimension {dim}")
        X=d[avail].copy()
        # median imputation + cross-sectional/time standardization
        X=X.apply(lambda s:s.fillna(s.median()))
        Z=(X-X.mean())/(X.std(ddof=0)+1e-12)
        # PCA first component
        u,s,v=linalg.svd(Z.to_numpy(),full_matrices=False)
        score=u[:,0]*s[0]
        if np.corrcoef(score,Z.mean(axis=1))[0,1]<0: score=-score
        score=(score-score.min())/(score.max()-score.min()+1e-12)
        d[dim]=score
    return d

def bayesian_linear_posterior(X,y,tau0=4.0,a0=2.0,b0=2.0):
    """Normal-Inverse-Gamma posterior for y=Xb+e, independent weak prior."""
    X=np.asarray(X,float); y=np.asarray(y,float)
    p=X.shape[1]
    V0=np.eye(p)*tau0
    Vn=np.linalg.inv(V0+X.T@X)
    bn=Vn@(X.T@y)
    an=a0+len(y)/2
    bn_scale=b0+0.5*(y@y-bn@np.linalg.inv(Vn)@bn)
    return bn,Vn,an,bn_scale

def posterior_draws(X,y,n=20000,seed=123):
    bn,Vn,an,bnscale=bayesian_linear_posterior(X,y)
    rng=np.random.default_rng(seed)
    sig2=1/rng.gamma(an,1/bnscale,size=n)
    B=np.array([rng.multivariate_normal(bn,Vn*s) for s in sig2])
    return B,sig2

def fit_model(panel):
    d=panel.dropna(subset=["GDP_GROWTH","K","H","T","I"]).copy()
    dims=["K","H","T","I"]
    # fixed effects via country and year dummies
    X=d[dims].copy()
    for a,b in [("K","H"),("K","T"),("K","I"),("H","T"),("H","I"),("T","I")]:
        X[a+b]=d[a]*d[b]
    X=sm.add_constant(X)
    X["lag_g"]=d.groupby("iso")["GDP_GROWTH"].shift(1)
    X["lag_g"]=X["lag_g"].fillna(d["GDP_GROWTH"].mean())
    # Country FE
    D=pd.get_dummies(d["iso"],drop_first=True,dtype=float)
    X=pd.concat([X,D],axis=1)
    y=d["GDP_GROWTH"].to_numpy()
    Xn=X.to_numpy(float)
    draws,sig2=posterior_draws(Xn,y,n=20000)
    return d,X,draws,sig2

def epi(df,weights=None):
    if weights is None: weights=np.array([.25,.25,.25,.25])
    z=df[["K","H","T","I"]].clip(.0001,.9999).to_numpy()
    return 100*np.exp(np.log(z)@weights)

def scenario_forecast(last,coef_draws,years=20,policy=None,threshold=80,seed=7):
    rng=np.random.default_rng(seed)
    n=len(coef_draws)
    out=[]
    dims=["K","H","T","I"]
    # coefficient positions: const,K,H,T,I,KH,KT,KI,HT,HI,TI,lag_g,...
    for s in range(n):
        state=last[dims].to_numpy(float).copy()
        g=float(last["GDP_GROWTH"])
        b=coef_draws[s]
        for h in range(1,years+1):
            if policy:
                state=np.clip(state+np.array(policy.get("annual_delta",[0,0,0,0])),.001,.999)
            feats=np.array([1,*state,
                            state[0]*state[1],state[0]*state[2],state[0]*state[3],
                            state[1]*state[2],state[1]*state[3],state[2]*state[3],g])
            # If FE coefficients exist, omit them for out-of-sample Bangladesh.
            pred=feats@b[:len(feats)]
            g=pred+rng.normal(0,0.75)
            # endogenous state transition: modest growth of capabilities
            state=np.clip(state+0.004*(1-state)+rng.normal(0,.008,4),.001,.999)
            out.append([s,h,*state,g,100*np.prod(state**.25)])
    return pd.DataFrame(out,columns=["draw","h","K","H","T","I","GDP_GROWTH","EPI"])

def run(demo=True):
    if demo:
        panel=demo_data()
    else:
        raw=fetch_wdi()
        wide=wide_wdi(raw)
        pwt=load_pwt()
        panel=build_dimensions(wide,pwt)
    panel.to_csv(OUT/"panel_4d.csv",index=False)

    if demo:
        d=panel
        X=d[["K","H","T","I"]].copy()
        for a,b in [("K","H"),("K","T"),("K","I"),("H","T"),("H","I"),("T","I")]:
            X[a+b]=d[a]*d[b]
        X["lag_g"]=d.groupby("iso")["GDP_GROWTH"].shift(1).fillna(d["GDP_GROWTH"].mean())
        X=sm.add_constant(X)
        draws,sig2=posterior_draws(X.to_numpy(float),d["GDP_GROWTH"],n=20000)
        Xcols=X.columns.tolist()
    else:
        d,X,draws,sig2=fit_model(panel); Xcols=X.columns.tolist()

    q=np.quantile(draws,[.025,.5,.975],axis=0)
    pd.DataFrame({"term":Xcols,"p025":q[0],"median":q[1],"p975":q[2]}).to_csv(OUT/"posterior_coefficients.csv",index=False)

    panel["EPI"]=epi(panel)
    latest=panel.sort_values("year").groupby("iso").tail(1)
    latest[["iso","year","K","H","T","I","EPI"]].to_csv(OUT/"latest_epi.csv",index=False)

    # Bangladesh scenario: baseline vs capability acceleration.
    bd=latest[latest.iso=="BGD"].iloc[0]
    base=scenario_forecast(bd,draws[:5000],years=20,policy={"annual_delta":[0,0,0,0]})
    reform=scenario_forecast(bd,draws[:5000],years=20,policy={"annual_delta":[.006,.008,.012,.010]})
    base["scenario"]="baseline"; reform["scenario"]="4D_reform"
    fc=pd.concat([base,reform],ignore_index=True)
    fc.to_csv(OUT/"forecast_distribution.csv",index=False)

    probs=fc.groupby(["scenario","h"]).apply(lambda x: pd.Series({
        "P_EPI_ge_threshold":np.mean(x.EPI>=80),
        "median_EPI":np.median(x.EPI),
        "p05_EPI":np.quantile(x.EPI,.05),
        "p95_EPI":np.quantile(x.EPI,.95)
    }),include_groups=False).reset_index()
    probs.to_csv(OUT/"forecast_probabilities.csv",index=False)

    # Sensitivity: perturb one annual policy dimension.
    sens=[]
    for i,name in enumerate(["K","H","T","I"]):
        p=[0,0,0,0]; p[i]=.01
        z=scenario_forecast(bd,draws[:3000],years=20,policy={"annual_delta":p})
        sens.append({"dimension":name,"policy_delta":.01,
                     "median_EPI_20y":np.median(z.EPI),
                     "P_EPI_ge_80":np.mean(z.EPI>=80)})
    pd.DataFrame(sens).to_csv(OUT/"policy_sensitivity.csv",index=False)

    # Figures
    for iso in ["JPN","BGD"]:
        qd=panel[panel.iso==iso].sort_values("year")
        plt.figure(figsize=(9,5))
        plt.plot(qd.year,qd.EPI)
        plt.title(f"4D Economic Power Index — {iso}")
        plt.xlabel("Year"); plt.ylabel("EPI (0–100)")
        plt.tight_layout(); plt.savefig(FIG/f"epi_{iso}.png",dpi=180); plt.close()

    plt.figure(figsize=(9,5))
    for scen,g in fc.groupby("scenario"):
        med=g.groupby("h").EPI.median()
        lo=g.groupby("h").EPI.quantile(.05)
        hi=g.groupby("h").EPI.quantile(.95)
        plt.plot(med.index,med.values,label=scen)
        plt.fill_between(med.index,lo.values,hi.values,alpha=.15)
    plt.axhline(80,linestyle="--")
    plt.xlabel("Years ahead"); plt.ylabel("EPI")
    plt.title("Bangladesh: simulated 4D reform scenarios")
    plt.legend(); plt.tight_layout()
    plt.savefig(FIG/"bangladesh_scenarios.png",dpi=180); plt.close()

    report=f"""# Automated Model Report

Mode: {"DEMO / SYNTHETIC" if demo else "REAL DATA"}

## Model
Bayesian linear growth model with four latent dimensions (K,H,T,I), six pairwise interaction terms, lagged growth, and country fixed effects.

## Important status
This report is **not** a completed causal estimate unless real WDI/PWT data are used and all validation diagnostics pass.

## Output files
- `panel_4d.csv`
- `posterior_coefficients.csv`
- `latest_epi.csv`
- `forecast_distribution.csv`
- `forecast_probabilities.csv`
- `policy_sensitivity.csv`
- `figures/epi_JPN.png`
- `figures/epi_BGD.png`
- `figures/bangladesh_scenarios.png`

## Interpretation
The EPI is a research index, not an official measure of national power. Threshold 80 is a declared analytical convention and must be sensitivity-tested.

## Validation still required
- rolling-origin out-of-sample forecasts;
- posterior predictive checks;
- calibration curves;
- alternative indicator sets;
- alternative normalization;
- alternative weights;
- structural-break tests;
- placebo countries;
- sensitivity to missing-data treatment;
- comparison with non-Bayesian benchmarks.
"""
    (OUT/"model_report.md").write_text(report,encoding="utf-8")
    print("Completed. See outputs/")

if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("--demo",action="store_true")
    ap.add_argument("--download",action="store_true")
    args=ap.parse_args()
    if not args.demo and not args.download:
        args.demo=True
    run(demo=args.demo)
