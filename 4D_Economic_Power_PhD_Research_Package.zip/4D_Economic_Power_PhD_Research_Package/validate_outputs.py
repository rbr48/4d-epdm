import pandas as pd, numpy as np
from pathlib import Path
root=Path(__file__).resolve().parent
out=root/'outputs'
fc=pd.read_csv(out/'forecast_probabilities.csv')
assert fc.P_EPI_ge_threshold.between(0,1).all()
assert fc.p05_EPI.le(fc.median_EPI).all() if hasattr(fc,'le') else True
print('Basic output integrity checks passed.')
print(fc.head(10).to_string(index=False))
